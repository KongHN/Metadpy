import pandas as pd
import arviz as az
from metadpy.bayesian import hmetad

def bayesian_analysis(data):
    all_results = []
    for subj_idx, group in data.groupby('Subj_idx'):  # 改为 'Subj_idx'
        try:
            model, trace = hmetad(
                data=group,
                nRatings=4,
                stimuli='Stimulus',
                accuracy='Accuracy',
                confidence='Confidence'
            )
            summary = az.summary(trace)
            summary['Subj_idx'] = subj_idx  # 改为 'Subj_idx'
            summary['Block'] = 'Overall'
            summary = summary.reset_index().rename(columns={'index': 'Variable'})
        except Exception as e:
            print(f"Error in Bayesian analysis for Subj_idx {subj_idx}: {e}")
            summary = pd.DataFrame({'Subj_idx': [subj_idx], 'Block': ['Overall'], 'Variable': ['meta_d', 'cS2', 'cS1']})
            for col in ['mean', 'sd', 'hdi_3%', 'hdi_97%']:
                summary[col] = 'FAL'

        print(f"Bayesian Analysis Summary for Subj_idx {subj_idx}:")
        print(summary)
        all_results.append(summary)

    return pd.concat(all_results, ignore_index=True)