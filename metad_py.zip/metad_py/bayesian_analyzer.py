import pandas as pd
import arviz as az
from metadpy.bayesian import hmetad


def bayesian_analysis(data):
    """
    使用分层贝叶斯建模估计整体的 meta - dprime
    :param data: 输入的 DataFrame 数据
    :return: 包含整体贝叶斯分析摘要统计信息的 DataFrame
    """
    try:
        model, trace = hmetad(
            data=data,
            nRatings=4,
            stimuli='Stimuli',
            accuracy='Accuracy',
            confidence='Confidence'
        )
        # 使用 arviz 库的 summary 函数计算并显示后验分布的摘要统计信息
        summary = az.summary(trace)
        summary['Subject'] = 'Overall'
        summary['Block'] = 'Overall'
        summary = summary.reset_index().rename(columns={'index': 'Variable'})
    except Exception as e:
        print(f"Error in Bayesian analysis: {e}")
        summary = pd.DataFrame({'Subject': ['Overall'], 'Block': ['Overall'], 'Variable': ['meta_d', 'cS2', 'cS1']})
        for col in ['mean', 'sd', 'hdi_3%', 'hdi_97%']:
            summary[col] = 'FAL'

    print("Bayesian Analysis Summary for Overall:")
    print(summary)

    return summary