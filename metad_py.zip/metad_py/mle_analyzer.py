import pandas as pd
import matplotlib.pyplot as plt
from metadpy.mle import metad

def mle_analysis(data):
    all_results = []
    for subj_idx, group in data.groupby('Subj_idx'):  # 改为 'Subj_idx'
        try:
            mle_result = metad(
                data=group,
                nRatings=4,
                stimuli='Stimulus',
                accuracy='Accuracy',
                confidence='Confidence',
                verbose=0
            )
            mle_result['Subj_idx'] = subj_idx  # 改为 'Subj_idx'
            mle_result['Block'] = 'Overall'
        except Exception as e:
            print(f"Error in MLE analysis for Subj_idx {subj_idx}: {e}")
            mle_result = pd.DataFrame({'Subj_idx': [subj_idx], 'Block': ['Overall']})
            for col in ['meta_d', 'cS2', 'cS1']:
                mle_result[col] = 'FAL'

        print(f"MLE Results for Subj_idx {subj_idx}:")
        print(mle_result)

        valid_mle_result = mle_result.drop(columns=['Subj_idx', 'Block'])
        if all([isinstance(x, (int, float)) for x in valid_mle_result.values.flatten()]):
            plt.figure(figsize=(8, 6))
            plt.bar(valid_mle_result.columns, valid_mle_result.values.flatten())
            plt.title(f'MLE Analysis Results for Subj_idx {subj_idx}')
            plt.ylabel('Value')
            plt.show()

        all_results.append(mle_result)

    return pd.concat(all_results, ignore_index=True)