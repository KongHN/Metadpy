import pandas as pd
import matplotlib.pyplot as plt
from metadpy.mle import metad


def mle_analysis(data):
    """
    使用最大似然估计（MLE）估计整体的 meta dprime
    :param data: 输入的 DataFrame 数据
    :return: MLE 分析结果
    """
    try:
        mle_result = metad(
            data=data,
            nRatings=4,
            stimuli='Stimuli',
            accuracy='Accuracy',
            confidence='Confidence',
            verbose=0
        )
        mle_result['Subject'] = 'Overall'
        mle_result['Block'] = 'Overall'
    except Exception as e:
        print(f"Error in MLE analysis: {e}")
        mle_result = pd.DataFrame({'Subject': ['Overall'], 'Block': ['Overall']})  # 创建一个包含错误信息的 DataFrame
        for col in ['meta_d', 'cS2', 'cS1']:
            mle_result[col] = 'FAL'  # 为结果中的 'meta_d', 'cS2', 'cS1' 列赋值为 'FAL'，表示失败

    print("MLE Results for Overall:")
    print(mle_result)

    # 可视化 MLE 结果，去除结果中的 'Subject' 和 'Block' 列
    valid_mle_result = mle_result.drop(columns=['Subject', 'Block'])
    if all([isinstance(x, (int, float)) for x in valid_mle_result.values.flatten()]):
        plt.figure(figsize=(8, 6))
        plt.bar(valid_mle_result.columns, valid_mle_result.values.flatten())
        plt.title('MLE Analysis Results for Overall')
        plt.ylabel('Value')
        plt.show()

    return mle_result