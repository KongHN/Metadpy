import pandas as pd
from sdt_analyzer import sdt_analysis
from mle_analyzer import mle_analysis
from bayesian_analyzer import bayesian_analysis

if __name__ == "__main__":
    file_path = r'F:\科研\02Metacog-617\data after separation\data_Zylberberg_2016(NAN)\data_Zylberberg_2016(NAN)_part1.csv'
    try:
        data = pd.read_excel(file_path)
        # 调整为 Excel 中的实际列名
        required_columns = ['Stimulus', 'Accuracy', 'Confidence', 'Response', 'Subj_idx', 'Block']  # 改为 'Subj_idx'
        for col in required_columns:
            if col not in data.columns:
                print(f"错误：数据中缺少 {col} 列")
                data = None
                break
    except FileNotFoundError:
        print(f"错误：未找到文件 {file_path}")
        data = None
    except Exception as e:
        print(f"错误：加载文件时出现问题 - {e}")
        data = None

    if data is not None:
        sdt_results = sdt_analysis(data)
        mle_results = mle_analysis(data)
        bayesian_results = bayesian_analysis(data)

        if sdt_results is not None and mle_results is not None and bayesian_results is not None:
            # 合并键改为 ['Subj_idx', 'Block']
            merged_results = pd.merge(sdt_results, mle_results, on=['Subj_idx', 'Block'], how='outer')
            final_results = pd.merge(merged_results, bayesian_results, on=['Subj_idx', 'Block'], how='outer')
            print("\n整合后的分析结果表格：")
            print(final_results)
        else:
            print("由于某些分析结果为空，无法合并表格。")