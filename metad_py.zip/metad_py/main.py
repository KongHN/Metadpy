import pandas as pd
from sdt_analyzer import sdt_analysis
from mle_analyzer import mle_analysis
from bayesian_analyzer import bayesian_analysis

if __name__ == "__main__":
    # 替换Excel 文件路径
    file_path = r'F:\科研\02Metacog-617\data after separation\Zylberberg_2016\data_Zylberberg_2016（first）.xlsx'
    try:
        data = pd.read_excel(file_path)
        required_columns = ['Stimuli', 'Accuracy', 'Confidence', 'Responses', 'Subject', 'Block']
        for col in required_columns:
            if col not in data.columns:
                print(f"错误：数据中缺少 {col} 列")
                data = None
                break
    except FileNotFoundError:
        print(f"错误：未找到文件 {file_path}")
        data = None
    except Exception as e:
        print(f"错误：加载文件时出现问题 - {e}")
        data = None

    if data is not None:
        sdt_results = sdt_analysis(data)  # SDT 分析
        mle_results = mle_analysis(data)  # MLE 分析
        bayesian_results = bayesian_analysis(data)  # 贝叶斯分析

        # 合并结果
        if sdt_results is not None and mle_results is not None and bayesian_results is not None:
            merged_results = pd.merge(sdt_results, mle_results, on=['Subject', 'Block'], how='outer')
            final_results = pd.merge(merged_results, bayesian_results, on=['Subject', 'Block'], how='outer')
            print("\n整合后的分析结果表格：")
            print(final_results)
        else:
            print("由于某些分析结果为空，无法合并表格。")
