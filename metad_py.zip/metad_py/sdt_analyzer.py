import pandas as pd
import matplotlib.pyplot as plt
from metadpy.sdt import criterion, dprime, rates, roc_auc, scores


def sdt_analysis(data):
    """
    进行整体的信号检测理论（SDT）分析
    :param data: 输入的 DataFrame 数据
    :return: 包含整体 SDT 分析结果的 DataFrame
    """
    try:
        crit = criterion(data)
        d_prime = dprime(data)
        hit_rate, false_alarm_rate = rates(data)
        auc = roc_auc(data, nRatings=4)
        sdt_scores = scores(data)
    except Exception as e:
        print(f"Error in SDT analysis: {e}")
        crit = d_prime = hit_rate = false_alarm_rate = auc = sdt_scores = 'FAL'

    # 构建整体的 SDT 分析结果字典
    result = {
        'Subject': 'Overall',
        'Block': 'Overall',
        'Criterion': crit,
        "d' (dprime)": d_prime,
        'Hit Rate': hit_rate,
        'False Alarm Rate': false_alarm_rate,
        'ROC AUC': auc,
        'Scores': sdt_scores
    }

    print("SDT Results for Overall:")
    print(result)

    # 若各项结果均为数值类型，则进行可视化
    if all([isinstance(x, (int, float)) for x in [crit, d_prime, hit_rate, false_alarm_rate]]):
        plt.figure(figsize=(12, 6))
        plt.subplot(1, 2, 1)
        plt.bar(['Criterion', "d'"], [crit, d_prime])
        plt.title('SDT: Criterion and d\' for Overall')
        plt.ylabel('Value')

        plt.subplot(1, 2, 2)
        plt.bar(['Hit Rate', 'False Alarm Rate'], [hit_rate, false_alarm_rate])
        plt.title('SDT: Hit Rate and False Alarm Rate for Overall')
        plt.ylabel('Rate')

        plt.tight_layout()
        plt.show()

    # 将结果转换为 DataFrame 并返回
    return pd.DataFrame([result])