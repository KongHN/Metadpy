import pandas as pd
import matplotlib.pyplot as plt
from metadpy.sdt import criterion, dprime, rates, roc_auc, scores

def sdt_analysis(data):
    """
    进行不同 Subj_idx 的信号检测理论（SDT）分析
    :param data: 输入的 DataFrame 数据（需包含 'Stimulus', 'Accuracy', 'Confidence', 'Response', 'Subj_idx'）
    :return: 包含不同 Subj_idx SDT 分析结果的 DataFrame
    """
    all_results = []

    for subj_idx, group in data.groupby('Subj_idx'):
        # 数据清洗：过滤缺失值
        group_clean = group.dropna(subset=['Stimulus', 'Accuracy', 'Confidence', 'Response'])

        try:
            # 直接调用 Pandas Flavor 方法（自动推断列名）
            crit = group_clean.criterion()
            d_prime = group_clean.dprime()
            hit_rate, false_alarm_rate = group_clean.rates()
            auc = group_clean.roc_auc(nRatings=4)
            sdt_scores = group_clean.scores()
        except Exception as e:
            print(f"Error in SDT analysis for Subj_idx {subj_idx}: {e}")
            crit = d_prime = hit_rate = false_alarm_rate = auc = sdt_scores = 'FAL'
        """
        try:
            # 假设这些函数支持指定列名，具体参数名需参考 metadpy.sdt 文档
            crit = criterion(group_clean, stimulus_col='Stimulus', response_col='Response', confidence_col='Confidence')
            d_prime = dprime(group_clean, stimulus_col='Stimulus', response_col='Response')
            hit_rate, false_alarm_rate = rates(group_clean, stimulus_col='Stimulus', response_col='Response')
            auc = roc_auc(group_clean, stimulus_col='Stimulus', response_col='Response', confidence_col='Confidence',
                          nRatings=4)
            sdt_scores = scores(group_clean, stimulus_col='Stimulus', response_col='Response',
                                confidence_col='Confidence')
        except Exception as e:
            print(f"Error in SDT analysis for Subj_idx {subj_idx}: {e}")
            crit = d_prime = hit_rate = false_alarm_rate = auc = sdt_scores = 'FAL'
        """

        # 构建结果字典
        result = {
            'Subj_idx': subj_idx,
            'Block': 'Overall',
            'Criterion': crit,
            "d' (dprime)": d_prime,
            'Hit Rate': hit_rate,
            'False Alarm Rate': false_alarm_rate,
            'ROC AUC': auc,
            'Scores': sdt_scores
        }

        print(f"SDT Results for Subj_idx {subj_idx}:")
        print(result)

        # 可视化结果
        if all([isinstance(x, (int, float)) for x in [crit, d_prime, hit_rate, false_alarm_rate]]):
            plt.figure(figsize=(12, 6))
            plt.subplot(1, 2, 1)
            plt.bar(['Criterion', "d'"], [crit, d_prime])
            plt.title(f'SDT: Criterion and d\' for Subj_idx {subj_idx}')
            plt.ylabel('Value')

            plt.subplot(1, 2, 2)
            plt.bar(['Hit Rate', 'False Alarm Rate'], [hit_rate, false_alarm_rate])
            plt.title(f'SDT: Hit Rate and False Alarm Rate for Subj_idx {subj_idx}')
            plt.ylabel('Rate')

            plt.tight_layout()
            plt.show()

        all_results.append(pd.DataFrame([result]))

    return pd.concat(all_results, ignore_index=True)